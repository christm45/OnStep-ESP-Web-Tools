// general purpose encoder class

#include "Encoder.h"

// get device ready for use
void Encoder::init() {
}

// set encoder origin
void Encoder::setOrigin(uint32_t count) {
  origin = count;
}
