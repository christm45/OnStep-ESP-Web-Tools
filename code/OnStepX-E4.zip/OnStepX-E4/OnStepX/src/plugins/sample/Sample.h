// Sample plugin
#pragma once

class Sample {
public:
  // the initialization method must be present and named: void init();
  void init();

  void loop();

private:

};

extern Sample sample;
