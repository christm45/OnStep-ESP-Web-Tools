// Website plugin
#pragma once

class Website {
public:
  // the initialization method must be present and named: void init();
  void init();

  void loop();

private:

};

extern Website website;
