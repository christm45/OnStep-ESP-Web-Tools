// -------------------------------------------------------------------------------------------------
// Pin map for Arduino M0
#pragma once

#if defined(__M0__)
  #define PINMAP_STR "ARDUINO M0"
  #error "No pinmap"
#endif
