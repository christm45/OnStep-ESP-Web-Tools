// -------------------------------------------------------------------------------------------------
// Pin map for ESP8266
#pragma once

#if defined(ESP8266)
  #define PINMAP_STR "ESP8266"
  #error "No pinmap"
#endif
